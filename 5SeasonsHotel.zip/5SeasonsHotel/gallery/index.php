<!DOCTYPE html>
<html>
  <head>
    <title>5 Season Hotel | Gallery</title>
    <link rel="stylesheet" type="text/css" href="\5SeasonsHotel\homePage\navigationMenu.css">
    <link rel="stylesheet" type="text/css" href="\5SeasonsHotel\includes\includeStyle\navigationMenu.css">
    
  </head>
  <body>
    <?php include('../includes/navigationMenu.php'); ?>

    <section>
    
    </section>

    <?php include('../includes/footer.php'); ?>
  </body>
</html>