<div class="navigationMenu">

    <img class="logo" src="\5SeasonsHotel\includes\includesImages\navigationMenuImages\logo.png" alt="logo">

    <nav>
        <ul>
            <li><a href="/5SeasonsHotel/"> Home</a></li>
            <li><a href="/5SeasonsHotel/Gallery/index.php"> Gallery</a></li>
            <li><a href="/5SeasonsHotel/contactUs/index.php"> Contact Us</a></li>
            <li><a href="/5SeasonsHotel/bookNow"> Book Now</a></li>
        </ul>
    </nav>
</div>
